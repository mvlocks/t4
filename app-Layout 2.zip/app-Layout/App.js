// App.js — navegação entre telas (telaAtual) e estado compartilhado do carrinho
import React, { useState } from 'react';
import { SafeAreaView, Alert, StyleSheet } from 'react-native';
import Cardapio from './src/components/cardapio';
import Carrinho from './src/components/carrinho';
import Checkout from './src/components/checkout';
import Confirmacao from './src/components/confirmacao';
import { cores, TAXA_ENTREGA } from './src/tema';

export default function App() {
  const [telaAtual, setTelaAtual] = useState('T1'); // T1 Cardápio · T2 Carrinho · T3 Checkout · T4 Confirmação
  const [carrinho, setCarrinho] = useState([]);
  const [cupom, setCupom] = useState('');
  const [pedido, setPedido] = useState(null);

  // Cálculos (RF03, RF08, RF10)
  const totalItens = carrinho.reduce((soma, item) => soma + item.qtd, 0);
  const subtotal = carrinho.reduce((soma, item) => soma + item.preco * item.qtd, 0);
  const desconto = cupom.trim().toUpperCase() === 'ALUNO10' ? subtotal * 0.1 : 0;
  const taxaEntrega = totalItens > 0 ? TAXA_ENTREGA : 0;
  const totalGeral = subtotal - desconto + taxaEntrega;

  // RF02: adiciona item (ou soma 1 na quantidade se já existir)
  const adicionarItem = (produto) => {
    setCarrinho((atual) => {
      const existe = atual.find((item) => item.id === produto.id);
      if (existe) {
        return atual.map((item) => (item.id === produto.id ? { ...item, qtd: item.qtd + 1 } : item));
      }
      return [...atual, { ...produto, qtd: 1 }];
    });
  };

  // RF07: altera a quantidade; ao chegar em 0 o item é removido
  const alterarQtd = (id, delta) => {
    setCarrinho((atual) =>
      atual.map((item) => (item.id === id ? { ...item, qtd: item.qtd + delta } : item)).filter((item) => item.qtd > 0)
    );
  };

  // RF17: número aleatório + Alert de sucesso (só depois de passar nas validações)
  const finalizarPedido = (dados) => {
    const numero = Math.floor(1000 + Math.random() * 9000);
    setPedido({ numero, dados, itens: carrinho, total: totalGeral });
    Alert.alert('Pedido confirmado!', `Seu pedido #${numero} foi realizado com sucesso.`);
    setTelaAtual('T4');
  };

  // RF18: limpa o carrinho e volta ao Cardápio
  const novoPedido = () => {
    setCarrinho([]);
    setCupom('');
    setPedido(null);
    setTelaAtual('T1');
  };

  return (
    <SafeAreaView style={styles.container}>
      {telaAtual === 'T1' && (
        <Cardapio
          onAdicionarItem={adicionarItem}
          totalItens={totalItens}
          onAbrirCarrinho={() => setTelaAtual('T2')}
        />
      )}

      {telaAtual === 'T2' && (
        <Carrinho
          carrinho={carrinho}
          onAlterarQtd={alterarQtd}
          subtotal={subtotal}
          desconto={desconto}
          taxaEntrega={taxaEntrega}
          totalGeral={totalGeral}
          cupom={cupom}
          onMudarCupom={setCupom}
          onVoltar={() => setTelaAtual('T1')}
          onContinuar={() => setTelaAtual('T3')}
        />
      )}

      {telaAtual === 'T3' && (
        <Checkout
          totalItens={totalItens}
          onVoltar={() => setTelaAtual('T2')}
          onFinalizar={finalizarPedido}
        />
      )}

      {telaAtual === 'T4' && pedido && <Confirmacao pedido={pedido} onNovoPedido={novoPedido} />}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: cores.branco },
});
