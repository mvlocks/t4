import { registerRootComponent } from 'expo';
import App from './App';

// Registra o componente raiz (Expo Go e build nativo)
registerRootComponent(App);
