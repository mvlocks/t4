# DelivExpress

App de pedidos & delivery em React Native + Expo.

## Como rodar
```bash
npm install
npx expo install --fix
npx expo start
```
Abra o Expo Go no celular e leia o QR Code.

## Estrutura
```
app-Layout/
├── App.js
├── index.js
├── app.json
├── package.json
├── assets/
└── src/
    ├── tema.js
    └── components/
        ├── comuns.jsx
        ├── cardapio.jsx
        ├── carrinho.jsx
        ├── checkout.jsx
        └── confirmacao.jsx
```
