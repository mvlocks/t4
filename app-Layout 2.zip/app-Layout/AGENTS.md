# DelivExpress — contexto do projeto

App de pedidos & delivery em React Native + Expo (JavaScript/JSX). Escopo: front-end (interface e validações), sem back-end.

- Telas em `src/components/`: cardapio.jsx (T1), carrinho.jsx (T2), checkout.jsx (T3), confirmacao.jsx (T4).
- Navegação por estado (`telaAtual`) e carrinho compartilhado em `App.js`.
- Cores, taxa de entrega e funções auxiliares em `src/tema.js`.
- Sem bibliotecas de UI prontas; permitido apenas React Navigation e @react-native-picker/picker.
