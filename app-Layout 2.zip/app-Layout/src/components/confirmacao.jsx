// src/components/confirmacao.jsx — T4 · Confirmação (RF16–RF18)
import React from 'react';
import { SafeAreaView, ScrollView, View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { cores, formatarPreco } from '../tema';

export default function Confirmacao({ pedido, onNovoPedido }) {
  const { numero, dados, itens, total } = pedido;

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.scroll}>
        {/* RF17 */}
        <View style={styles.centro}>
          <View style={styles.check}>
            <Text style={styles.textoCheck}>✓</Text>
          </View>
          <Text style={styles.titulo}>Pedido confirmado!</Text>
          <Text style={styles.numeroPedido}>Pedido #{numero}</Text>
        </View>

        {/* RF16 — fundo branco, com linhas finas separando as seções (igual ao mockup, sem caixa cinza) */}
        <View style={styles.resumo}>
          {itens.map((item) => (
            <Text key={item.id} style={styles.textoResumo}>
              {item.qtd}x {item.nome}
            </Text>
          ))}
          <View style={styles.linhaTotal}>
            <Text style={styles.totalRotulo}>Total pago</Text>
            <Text style={styles.totalValor}>{formatarPreco(total)}</Text>
          </View>
          <View style={styles.detalhes}>
            <Text style={styles.descricao}>
              Entrega: {dados.endereco}, {dados.numero}
              {dados.complemento ? ` - ${dados.complemento}` : ''}
            </Text>
            <Text style={styles.descricao}>Pagamento: {dados.pagamento}</Text>
            {dados.precisaTroco && dados.trocoPara !== '' && (
              <Text style={styles.descricao}>Troco para: R$ {dados.trocoPara}</Text>
            )}
          </View>
        </View>
      </ScrollView>

      {/* RF18 — fixo embaixo da tela, igual ao mockup */}
      <View style={styles.rodape}>
        <TouchableOpacity style={styles.botao} onPress={onNovoPedido} activeOpacity={0.7}>
          <Text style={styles.textoBotao}>Fazer novo pedido</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: cores.branco },
  scroll: { padding: 16, paddingBottom: 16, flexGrow: 1 },
  rodape: { padding: 16, paddingTop: 0 },
  centro: { alignItems: 'center', marginTop: 16 },
  check: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: cores.sucesso,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textoCheck: { color: cores.branco, fontSize: 32, fontWeight: 'bold' },
  titulo: { fontSize: 22, fontWeight: 'bold', color: cores.escura, marginTop: 12 },
  numeroPedido: { fontSize: 16, color: cores.primaria, marginTop: 4 },
  resumo: { backgroundColor: cores.branco, marginVertical: 16, paddingVertical: 4 },
  textoResumo: { fontSize: 16, color: cores.escura, marginBottom: 4 },
  // "listras": linha fina acima e abaixo do total, como no mockup — sem caixa cinza de fundo
  linhaTotal: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
    paddingVertical: 10,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: cores.borda,
  },
  totalRotulo: { fontSize: 16, fontWeight: 'bold', color: cores.escura },
  totalValor: { fontSize: 16, fontWeight: 'bold', color: cores.sucesso },
  detalhes: { marginTop: 10 },
  descricao: { fontSize: 14, color: cores.secundaria, marginTop: 2 },
  botao: {
    backgroundColor: cores.sucesso,
    minHeight: 52,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  textoBotao: { color: cores.branco, fontSize: 16, fontWeight: 'bold' },
});
