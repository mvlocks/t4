// src/components/cardapio.jsx — T1 · Cardápio (RF01–RF05)
import React, { useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, Image, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { cores, formatarPreco } from '../tema';
import { Cabecalho } from './comuns';
import { IMG_XBURGER, IMG_XSALADA, IMG_XBACON, IMG_XFRANGO, IMG_BATATA } from '../imagens';

// RF01: no mínimo 5 produtos — cada um com a imagem certa (hambúrguer/batata desenhado, RF04: width/height)
const PRODUTOS = [
  { id: 1, nome: 'X-Burger', descricao: 'Pão, carne e queijo', preco: 24.9, imagem: IMG_XBURGER },
  { id: 2, nome: 'X-Salada', descricao: 'Alface, tomate e carne', preco: 27.9, imagem: IMG_XSALADA },
  { id: 3, nome: 'X-Bacon', descricao: 'Bacon crocante e queijo', preco: 29.9, imagem: IMG_XBACON },
  { id: 4, nome: 'X-Frango', descricao: 'Frango grelhado e maionese', preco: 26.9, imagem: IMG_XFRANGO },
  { id: 5, nome: 'Batata Frita', descricao: 'Porção crocante', preco: 15.9, imagem: IMG_BATATA },
];

export default function Cardapio({ onAdicionarItem, totalItens, onAbrirCarrinho }) {
  const [busca, setBusca] = useState(''); // RF05 (extra)
  const filtrados = PRODUTOS.filter((p) => p.nome.toLowerCase().includes(busca.trim().toLowerCase()));

  return (
    <SafeAreaView style={styles.safe}>
      <Cabecalho
        titulo="DelivExpress"
        direita={
          // RF03: contador em tempo real; toque abre o carrinho
          <TouchableOpacity style={styles.badge} onPress={onAbrirCarrinho} activeOpacity={0.7}>
            <Text style={styles.textoBadge}>🛒 {totalItens}</Text>
          </TouchableOpacity>
        }
      />
      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
        <TextInput
          style={styles.busca}
          value={busca}
          onChangeText={setBusca}
          placeholder="Buscar lanche..."
          placeholderTextColor={cores.secundaria}
        />
        {filtrados.map((p) => (
          <View key={p.id} style={styles.card}>
            {/* RF04: imagem remota exige width/height (no style) */}
            <Image source={{ uri: p.imagem }} style={styles.imagem} />
            <View style={styles.info}>
              <Text style={styles.nome}>{p.nome}</Text>
              <Text style={styles.descricao}>{p.descricao}</Text>
              <Text style={styles.preco}>{formatarPreco(p.preco)}</Text>
            </View>
            {/* RF02 */}
            <TouchableOpacity style={styles.botaoAdicionar} onPress={() => onAdicionarItem(p)} activeOpacity={0.7}>
              <Text style={styles.textoBotao}>+ Add</Text>
            </TouchableOpacity>
          </View>
        ))}
        {filtrados.length === 0 && <Text style={styles.descricao}>Nenhum lanche encontrado.</Text>}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: cores.branco },
  scroll: { padding: 16, paddingBottom: 32 },
  badge: {
    backgroundColor: cores.sucesso,
    minHeight: 44,
    minWidth: 60,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 12,
  },
  textoBadge: { color: cores.branco, fontSize: 16, fontWeight: 'bold' },
  busca: {
    minHeight: 48,
    borderWidth: 1,
    borderColor: cores.borda,
    borderRadius: 8,
    paddingHorizontal: 12,
    fontSize: 16,
    color: cores.escura,
    backgroundColor: cores.fundo,
  },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: cores.fundo,
    borderRadius: 10,
    padding: 10,
    marginTop: 12,
  },
  imagem: { width: 64, height: 64, borderRadius: 8, backgroundColor: cores.borda },
  info: { flex: 1, marginHorizontal: 10 },
  nome: { fontSize: 16, fontWeight: 'bold', color: cores.escura },
  descricao: { fontSize: 14, color: cores.secundaria, marginTop: 2 },
  preco: { fontSize: 16, fontWeight: 'bold', color: cores.erro, marginTop: 4 },
  botaoAdicionar: {
    backgroundColor: cores.sucesso,
    minHeight: 44,
    minWidth: 64,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textoBotao: { color: cores.branco, fontSize: 14, fontWeight: 'bold' },
});
