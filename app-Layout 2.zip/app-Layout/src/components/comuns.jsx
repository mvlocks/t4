// src/components/comuns.jsx — componentes reutilizados nas telas
import React from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { cores } from '../tema';

// Campo de texto controlado: rótulo + TextInput + mensagem de erro (seção 4.2)
export function Campo({ rotulo, valor, onChange, placeholder, keyboardType = 'default', maxLength, erro }) {
  return (
    <View style={styles.campoBox}>
      <Text style={styles.rotulo}>{rotulo}</Text>
      <TextInput
        style={[styles.input, erro ? styles.inputErro : null]}
        value={valor}
        onChangeText={onChange}
        placeholder={placeholder}
        placeholderTextColor={cores.secundaria}
        keyboardType={keyboardType}
        maxLength={maxLength}
      />
      {erro ? <Text style={styles.textoErro}>{erro}</Text> : null}
    </View>
  );
}

// Cabeçalho azul das telas (com botão voltar opcional)
export function Cabecalho({ titulo, onVoltar, direita }) {
  return (
    <View style={styles.cabecalho}>
      {onVoltar ? (
        <TouchableOpacity style={styles.areaToque} onPress={onVoltar} activeOpacity={0.7}>
          <Text style={styles.tituloCabecalho}>← {titulo}</Text>
        </TouchableOpacity>
      ) : (
        <Text style={styles.tituloCabecalho}>{titulo}</Text>
      )}
      {direita}
    </View>
  );
}

const styles = StyleSheet.create({
  campoBox: { marginTop: 14 },
  rotulo: { fontSize: 14, fontWeight: 'bold', color: cores.escura, marginBottom: 6 },
  input: {
    minHeight: 48,
    borderWidth: 1,
    borderColor: cores.borda,
    borderRadius: 8,
    paddingHorizontal: 12,
    fontSize: 16,
    color: cores.escura,
    backgroundColor: cores.branco,
  },
  inputErro: { borderColor: cores.erro },
  textoErro: { color: cores.erro, fontSize: 14, marginTop: 4 },
  cabecalho: {
    backgroundColor: cores.primaria,
    minHeight: 56,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginHorizontal: 16,
    marginTop: 12,
    borderRadius: 10,
  },
  areaToque: { minHeight: 48, justifyContent: 'center' },
  tituloCabecalho: { color: cores.branco, fontSize: 20, fontWeight: 'bold' },
});
