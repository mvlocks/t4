// src/components/checkout.jsx — T3 · Checkout / Entrega (RF11–RF15, seção 4)
import React, { useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, TouchableOpacity, Switch, StyleSheet } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { cores, soDigitos } from '../tema';
import { Cabecalho, Campo } from './comuns';

export default function Checkout({ totalItens, onVoltar, onFinalizar }) {
  // RNF02: todos os campos controlados com useState
  const [nome, setNome] = useState('');
  const [telefone, setTelefone] = useState('');
  const [cep, setCep] = useState('');
  const [endereco, setEndereco] = useState('');
  const [numero, setNumero] = useState('');
  const [complemento, setComplemento] = useState('');
  const [referencia, setReferencia] = useState('');
  const [pagamento, setPagamento] = useState('');
  const [precisaTroco, setPrecisaTroco] = useState(false);
  const [trocoPara, setTrocoPara] = useState('');
  const [erros, setErros] = useState({});

  // Seção 4.1: validações e mensagens de erro
  const validarPedido = () => {
    const novos = {};
    if (totalItens === 0) novos.carrinho = 'Seu carrinho está vazio.';
    if (nome.trim() === '') novos.nome = 'Informe seu nome.';
    if (telefone.length < 10) novos.telefone = 'Telefone inválido.';
    if (cep.length !== 8) novos.cep = 'CEP deve ter 8 dígitos.';
    if (endereco.trim() === '') novos.endereco = 'Informe o endereço.';
    if (!/^[0-9]+$/.test(numero)) novos.numero = 'Número inválido.';
    if (pagamento === '') novos.pagamento = 'Escolha a forma de pagamento.';
    setErros(novos);

    if (Object.keys(novos).length === 0) {
      onFinalizar({ nome, telefone, cep, endereco, numero, complemento, referencia, pagamento, precisaTroco, trocoPara });
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
        <View>
          <Cabecalho titulo="Dados de Entrega" onVoltar={onVoltar} />
        </View>

        <View>
          {erros.carrinho ? <Text style={styles.textoErro}>{erros.carrinho}</Text> : null}

          <Campo rotulo="Nome" valor={nome} onChange={setNome} placeholder="Maria Silva" erro={erros.nome} />
          <Campo
            rotulo="Telefone"
            valor={telefone}
            onChange={(t) => setTelefone(soDigitos(t))}
            placeholder="11999999999"
            keyboardType="phone-pad"
            maxLength={11}
            erro={erros.telefone}
          />
          <Campo
            rotulo="CEP"
            valor={cep}
            onChange={(t) => setCep(soDigitos(t))}
            placeholder="Somente números"
            keyboardType="numeric"
            maxLength={8}
            erro={erros.cep}
          />
          <Campo rotulo="Endereço" valor={endereco} onChange={setEndereco} placeholder="Rua, avenida..." erro={erros.endereco} />
          <Campo
            rotulo="Número"
            valor={numero}
            onChange={(t) => setNumero(soDigitos(t))}
            placeholder="123"
            keyboardType="numeric"
            erro={erros.numero}
          />
          <Campo rotulo="Complemento (opcional)" valor={complemento} onChange={setComplemento} placeholder="Apto, bloco..." />
          <Campo rotulo="Referência" valor={referencia} onChange={setReferencia} placeholder="Próximo a..." />

          {/* RF12 */}
          <View style={styles.campoBox}>
            <Text style={styles.rotulo}>Forma de pagamento</Text>
            <View style={[styles.pickerBox, erros.pagamento ? styles.pickerErro : null]}>
              <Picker
                selectedValue={pagamento}
                onValueChange={(valor) => {
                  setPagamento(valor);
                  if (valor !== 'Dinheiro') {
                    setPrecisaTroco(false);
                    setTrocoPara('');
                  }
                }}
                style={styles.picker}
              >
                <Picker.Item label="Selecione..." value="" />
                <Picker.Item label="Cartão" value="Cartão" />
                <Picker.Item label="Pix" value="Pix" />
                <Picker.Item label="Dinheiro" value="Dinheiro" />
              </Picker>
            </View>
            {erros.pagamento ? <Text style={styles.textoErro}>{erros.pagamento}</Text> : null}
          </View>

          {/* RF13 (extra): troco só para Dinheiro */}
          {pagamento === 'Dinheiro' && (
            <View style={styles.campoBox}>
              <View style={styles.linhaSwitch}>
                <Text style={styles.rotuloSwitch}>Preciso de troco</Text>
                <Switch
                  value={precisaTroco}
                  onValueChange={setPrecisaTroco}
                  trackColor={{ false: cores.borda, true: cores.sucesso }}
                  thumbColor={cores.branco}
                />
              </View>
              {precisaTroco && (
                <Campo
                  rotulo="Troco para (R$)"
                  valor={trocoPara}
                  onChange={(t) => setTrocoPara(soDigitos(t))}
                  placeholder="50"
                  keyboardType="numeric"
                />
              )}
            </View>
          )}
        </View>

        <View>
          {/* RF15 */}
          <TouchableOpacity style={styles.botaoPrincipal} onPress={validarPedido} activeOpacity={0.7}>
            <Text style={styles.textoBotao}>Finalizar pedido</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: cores.branco },
  scroll: { padding: 16, paddingBottom: 32 },
  campoBox: { marginTop: 14 },
  rotulo: { fontSize: 14, fontWeight: 'bold', color: cores.escura, marginBottom: 6 },
  textoErro: { color: cores.erro, fontSize: 14, marginTop: 4 },
  pickerBox: {
    borderWidth: 1,
    borderColor: cores.borda,
    borderRadius: 8,
    backgroundColor: cores.fundo,
    justifyContent: 'center',
    minHeight: 48,
  },
  pickerErro: { borderColor: cores.erro },
  picker: { color: cores.escura },
  linhaSwitch: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', minHeight: 48 },
  rotuloSwitch: { fontSize: 16, color: cores.escura },
  botaoPrincipal: {
    backgroundColor: cores.primaria,
    minHeight: 52,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 16,
  },
  textoBotao: { color: cores.branco, fontSize: 16, fontWeight: 'bold' },
});
