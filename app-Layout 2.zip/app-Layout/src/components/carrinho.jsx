// src/components/carrinho.jsx — T2 · Carrinho (RF06–RF10)
import React from 'react';
import { SafeAreaView, ScrollView, View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { cores, formatarPreco } from '../tema';
import { Cabecalho, Campo } from './comuns';

export default function Carrinho({
  carrinho,
  onAlterarQtd,
  subtotal,
  desconto,
  taxaEntrega,
  totalGeral,
  cupom,
  onMudarCupom,
  onVoltar,
  onContinuar,
}) {
  const vazio = carrinho.length === 0;

  return (
    <SafeAreaView style={styles.safe}>
      <Cabecalho titulo="Meu Carrinho" onVoltar={onVoltar} />
      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
        {vazio && <Text style={styles.descricao}>Seu carrinho está vazio.</Text>}

        {/* RF06 */}
        {carrinho.map((item) => (
          <View key={item.id} style={styles.linhaItem}>
            <View style={styles.info}>
              <Text style={styles.nome}>{item.nome}</Text>
              <Text style={styles.descricao}>{formatarPreco(item.preco)} un.</Text>
            </View>
            {/* RF07 */}
            <View style={styles.qtdBox}>
              <TouchableOpacity style={styles.botaoQtd} onPress={() => onAlterarQtd(item.id, -1)}>
                <Text style={styles.textoQtd}>−</Text>
              </TouchableOpacity>
              <Text style={styles.qtdTexto}>{item.qtd}</Text>
              <TouchableOpacity style={styles.botaoQtd} onPress={() => onAlterarQtd(item.id, 1)}>
                <Text style={styles.textoQtd}>+</Text>
              </TouchableOpacity>
            </View>
            <Text style={styles.subtotalItem}>{formatarPreco(item.preco * item.qtd)}</Text>
          </View>
        ))}

        {/* RF10 (extra) */}
        <Campo rotulo="Cupom de desconto" valor={cupom} onChange={onMudarCupom} placeholder="ALUNO10" />

        {/* RF08 */}
        <View style={styles.resumo}>
          <View style={styles.linhaResumo}>
            <Text style={styles.descricao}>Subtotal</Text>
            <Text style={styles.valorResumo}>{formatarPreco(subtotal)}</Text>
          </View>
          {desconto > 0 && (
            <View style={styles.linhaResumo}>
              <Text style={styles.descricao}>Desconto (10%)</Text>
              <Text style={styles.valorResumo}>- {formatarPreco(desconto)}</Text>
            </View>
          )}
          <View style={styles.linhaResumo}>
            <Text style={styles.descricao}>Entrega</Text>
            <Text style={styles.valorResumo}>{formatarPreco(taxaEntrega)}</Text>
          </View>
          <View style={styles.linhaResumo}>
            <Text style={styles.totalRotulo}>TOTAL</Text>
            <Text style={styles.totalValor}>{formatarPreco(totalGeral)}</Text>
          </View>
        </View>

        {/* RF09: desabilitado com carrinho vazio */}
        <TouchableOpacity
          style={[styles.botaoPrincipal, vazio ? styles.botaoDesabilitado : null]}
          onPress={onContinuar}
          disabled={vazio}
          activeOpacity={0.7}
        >
          <Text style={styles.textoBotao}>Continuar</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: cores.branco },
  scroll: { padding: 16, paddingBottom: 32 },
  linhaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: cores.borda,
  },
  info: { flex: 1, marginRight: 10 },
  nome: { fontSize: 16, fontWeight: 'bold', color: cores.escura },
  descricao: { fontSize: 14, color: cores.secundaria, marginTop: 2 },
  qtdBox: { flexDirection: 'row', alignItems: 'center' },
  botaoQtd: {
    width: 44,
    height: 44,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: cores.primaria,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textoQtd: { fontSize: 20, color: cores.primaria, fontWeight: 'bold' },
  qtdTexto: { fontSize: 16, color: cores.escura, marginHorizontal: 10, minWidth: 16, textAlign: 'center' },
  subtotalItem: { fontSize: 14, fontWeight: 'bold', color: cores.escura, marginLeft: 10, minWidth: 70, textAlign: 'right' },
  resumo: { backgroundColor: cores.fundo, borderRadius: 10, padding: 14, marginVertical: 16 },
  linhaResumo: { flexDirection: 'row', justifyContent: 'space-between', marginVertical: 3 },
  valorResumo: { fontSize: 14, color: cores.escura },
  totalRotulo: { fontSize: 16, fontWeight: 'bold', color: cores.escura },
  totalValor: { fontSize: 16, fontWeight: 'bold', color: cores.sucesso },
  botaoPrincipal: {
    backgroundColor: cores.primaria,
    minHeight: 52,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  botaoDesabilitado: { opacity: 0.4 },
  textoBotao: { color: cores.branco, fontSize: 16, fontWeight: 'bold' },
});
