// src/imagens.js — fotos reais dos produtos (Wikimedia Commons, licença livre/CC)
// Usa o redirecionador oficial Special:FilePath, que aponta sempre para o arquivo original.
const WIKI = 'https://commons.wikimedia.org/wiki/Special:FilePath/';

export const IMG_XBURGER = WIKI + "McDonald%27s_Double_Cheeseburger_(1).jpg";
export const IMG_XSALADA = WIKI + 'Veggie_burger_flickr_user_bradleyj_creative_commons.jpg';
export const IMG_XBACON = WIKI + 'Big_Mac_hamburger.jpg';
export const IMG_XFRANGO = WIKI + 'McD-McChicken.jpg';
export const IMG_BATATA = WIKI + 'French_Fries.JPG';
