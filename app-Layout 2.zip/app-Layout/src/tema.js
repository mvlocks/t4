// src/tema.js — cores (seção 5.1), taxa fixa e funções auxiliares
export const cores = {
  primaria: '#3D5AFE',
  sucesso: '#2EC478',
  escura: '#202A44',
  secundaria: '#464E5C',
  erro: '#EB5757',
  fundo: '#F2F4F7',
  branco: '#FFFFFF',
  borda: '#D5D9E0',
};

export const TAXA_ENTREGA = 6;

export const formatarPreco = (valor) => 'R$ ' + valor.toFixed(2).replace('.', ',');

// RNF08: mantém só dígitos (telefone, CEP, número, troco)
export const soDigitos = (texto) => texto.replace(/[^0-9]/g, '');
